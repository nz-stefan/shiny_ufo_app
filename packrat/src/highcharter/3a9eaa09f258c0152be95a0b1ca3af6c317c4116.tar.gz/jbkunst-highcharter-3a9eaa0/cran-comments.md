## Resubmission

* fix url with 404 in `hc_theme_sml`

Thanks!
