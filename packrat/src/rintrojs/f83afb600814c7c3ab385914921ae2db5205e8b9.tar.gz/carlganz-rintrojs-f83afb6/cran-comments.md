# First submission rintrojs 0.1.2

## Test environments

Local OS X, R 3.3.1 (Also on Travis CI)

Local Windows 10, R 3.3.1

Local Ubuntu 12.04, R 3.3.1 (Also on Travis CI)

All R-Hub platforms passed

## R CMD Check

0 errors | 0 warnings | 0 notes

## Changes

- Fix bug with Shiny modules