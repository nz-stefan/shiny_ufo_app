library(testthat)
library(rintrojs)

test_check("rintrojs")
